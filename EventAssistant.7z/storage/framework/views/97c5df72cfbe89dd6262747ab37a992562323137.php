<header id="header"><a href="<?php echo e(url('/')); ?>" class="logo"><strong><?php echo e(config('app.name')); ?></strong></a>
    <?php if(Route::has('login')): ?>
        <nav>
            <ul>   
                <?php if(auth()->guard()->check()): ?>         
                    <li class="submenu">
                        <a href="#">
                            <img class="img-profile" src="<?php echo e(Auth::user()->profileImage()); ?>">
                            <?php echo e(Auth::user()->name); ?>

                            <i class="fas fa-angle-down" style="vertical-align: middle;"></i>
                        </a>
                        <ul class="dropdown">

                            <?php if (\Illuminate\Support\Facades\Blade::check('hasRole', 'user')): ?>
                                <li>
                                    <a href="<?php echo e(route('public.dashboard')); ?>" title="Dashboard">
                                        <i class="fas fa-user-cog"></i>
                                        Dashboard
                                    </a>
                                </li>
                                <li>
                                    <a href="<?php echo e(route('public.user.show', Auth::user())); ?>" title="View Profile">
                                        <i class="fas fa-user"></i>
                                        View Profile
                                    </a>
                                </li>
                            <?php endif; ?>

                            <?php if (\Illuminate\Support\Facades\Blade::check('hasRole', 'admin')): ?>
                                <li>
                                    <a href="<?php echo e(route('admin.dashboard')); ?>" title="BackOffice">
                                        <i class="fas fa-cogs"></i>
                                        BackOffice
                                    </a>
                                </li>
                            <?php endif; ?>
                            
                                <li>
                                    <a href="<?php echo e(route('logout')); ?>"
                                            onclick="event.preventDefault();
                                            document.getElementById('logout-form').submit();" title="Logout">
                                        <i class="fas fa-sign-out-alt"></i>
                                        <?php echo e(__('Logout')); ?>

                                    </a>
                                </li>                                   

                            <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                                <?php echo csrf_field(); ?>
                            </form>

                         </ul>
                    </li>
                <?php else: ?>
                    <li><a href="<?php echo e(route('login')); ?>" title="Login"><?php echo e(__('Login')); ?></a></li>

                    <?php if(Route::has('register')): ?>
                        <li><a href="<?php echo e(route('register')); ?>" title="Sign Up"><?php echo e(__('Sign Up')); ?></a></li>
                    <?php endif; ?>
                <?php endif; ?>                
            </ul>
        </nav>
    <?php endif; ?>
</header><?php /**PATH C:\laragon\www\EventAssistant\resources\views/public/includes/header.blade.php ENDPATH**/ ?>