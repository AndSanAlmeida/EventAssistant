<?php $__env->startSection('title', 'Regiter'); ?>

<?php $__env->startSection('content'); ?>

<div class="row justify-content-center">

    <div class="col-sm-12 col-lg-7">

        <div class="card o-hidden border-0 shadow-lg my-5">
            <div class="card-body p-0">
                <!-- Nested Row within Card Body -->
                <div class="row">
                    <div class="col-lg-12">
                        <div class="p-5">
                            <div class="text-center">
                                <h1 class="h4 text-gray-900 mb-4">Create an Account!</h1>
                            </div>
                            <form class="user" method="POST" action="<?php echo e(route('register')); ?>">
                                <?php echo csrf_field(); ?>
                                
                                <div class="form-group">

                                    <input id="name" type="text" class="form-control form-control-user <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="name" value="<?php echo e(old('name')); ?>" required placeholder="First and Last Name" autocomplete="name" autofocus>

                                    
                                    <span id="checkName"></span>

                                    <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                                </div>
                                <div class="form-group">

                                    <input id="email" type="email" class="form-control form-control-user <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="email" value="<?php echo e(old('email')); ?>" required placeholder="Email Address" autocomplete="email">

                                    
                                    <span id="checkEmail"></span>

                                    <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                                </div>
                                <div class="form-group row">
                                    <div class="col-sm-6 mb-3 mb-sm-0">

                                        <input id="password" type="password" class="form-control form-control-user <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="password" required placeholder="Password" autocomplete="new-password">

                                        
                                        <span id="checkPassword"></span>

                                        <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="invalid-feedback" role="alert">
                                                <strong><?php echo e($message); ?></strong>
                                            </span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                                    </div>
                                    <div class="col-sm-6">

                                        <input id="password-confirm" type="password" class="form-control form-control-user" name="password_confirmation" required placeholder="Repeat Password" autocomplete="new-password">

                                        
                                        <span id="checkPasswordConfirm"></span>

                                    </div>
                                </div>

                                <button type="submit" class="btn btn-danger btn-user btn-block">
                                    <?php echo e(__('Register')); ?>

                                </button>

                                

                            </form>
                            <hr>

                            <?php if(Route::has('password.request')): ?>
                                <div class="text-center">
                                    <a class="small" href="<?php echo e(route('password.request')); ?>">
                                        <?php echo e(__('Forgot Your Password?')); ?>

                                    </a>
                                </div>
                            <?php endif; ?>

                            <?php if(Route::has('login')): ?>
                                <div class="text-center">
                                    <a class="small" href="<?php echo e(route('login')); ?>">
                                        <?php echo e(__('Already have an account? Login!')); ?>

                                    </a>
                                </div>
                            <?php endif; ?>

                            <div class="text-center">
                                <a class="small" href="<?php echo e(url('/')); ?>">
                                    <?php echo e(__('Back to Website')); ?>

                                </a>
                            </div>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>




<script src="<?php echo e(asset('vendor/jquery/jquery.min.js')); ?>"></script>
<script>

    $("#name").keyup(function(e) {       
        
        var name = e.target.value.length;
        var errorName = 'Name should have more then 2 charaters';

        if(name <= 2) {
            $('#name').attr('class', 'form-control form-control-user is-invalid');
            $('#checkName').attr('class', 'invalid-feedback')
                           .attr('role', 'alert')
                           .html('<strong>' + errorName + '</strong>');
        } else {
            $('#name').attr('class', 'form-control form-control-user');
            $('#checkName').html('');
        }
    });    

    $("#email").keyup(function(e) {       

        var APP_URL = <?php echo json_encode(url('/')); ?>;
        var email = e.target.value;

        $.ajax({
            url: APP_URL + '/api/user/check/' + email,
        }).done(function(response) {
            // console.log(response)
            if(response.containsError) {
                $('#email').attr('class', 'form-control form-control-user is-invalid');
                $('#checkEmail').attr('class', 'invalid-feedback')
                                .attr('role', 'alert')
                                .html('<strong>' + response.error + '</strong>');
            } else {
                $('#email').attr('class', 'form-control form-control-user');
                $('#checkEmail').html('');
            }
        });
    });

    $("#password").keyup(function(e) {       
        
        var password = e.target.value.length;
        var errorPassword = 'Password should have more than 7 charaters';

        if(password <= 7) {
            $('#password').attr('class', 'form-control form-control-user is-invalid');
            $('#checkPassword').attr('class', 'invalid-feedback')
                               .attr('role', 'alert')
                               .html('<strong>' + errorPassword + '</strong>');
        } else {
            $('#password').attr('class', 'form-control form-control-user');
            $('#checkPassword').html('');
        }
    });  

    $("#password-confirm").keyup(function(e) {       
        
        var password = e.target.value;
        var errorPasswordConfirm = 'Passwords are different!';

        if(password !== $('#password').val()) {
            $('#password-confirm').attr('class', 'form-control form-control-user is-invalid');
            $('#checkPasswordConfirm').attr('class', 'invalid-feedback')
                                      .attr('role', 'alert')
                                      .html('<strong>' + errorPasswordConfirm + '</strong>');
        } else {
            $('#password-confirm').attr('class', 'form-control form-control-user');
            $('#checkPasswordConfirm').html('');
        }
    });  
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.authMaster', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\EventAssistant\resources\views/auth/register.blade.php ENDPATH**/ ?>