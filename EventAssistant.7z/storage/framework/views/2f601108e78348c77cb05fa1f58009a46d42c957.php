<?php $__env->startSection('title', 'Create Event'); ?>

<?php $__env->startSection('content'); ?>

<section class="main">

  <?php echo $__env->make('public.partials._alerts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

	<div class="row gtr-200">
	  <div class="col-12">
		<h2>Event</h2>
	  </div>
	</div>

	<div class="row gtr-uniform">
		<div class="col-12">
			<h4>Add New Event</h4>
		</div>
	</div>

  <br>

	<form action="<?php echo e(route('public.event.store')); ?>" enctype="form-data" method="POST">
      <?php echo csrf_field(); ?>

      <div class="col-12">  
        <div class="row gtr-uniform">

          
          <div class="col-2 alg-self-center">
            <label for="name">Name</label>
          </div>
          <div class="col-10">              
            <input id="name"
                   type="text"
                   class="<?php echo e($errors->has('name') ? ' is-invalid' : ''); ?>"
                   name="name"
                   value="<?php echo e(old('name')); ?>"
                   required
                   autocomplete="Name" autofocus>

              <?php if($errors->has('name')): ?>
                <span class="invalid-feedback" role="alert">
                    <strong><?php echo e($errors->first('name')); ?></strong>
                </span>
              <?php endif; ?>
          </div>

          
          <div class="col-2 alg-self-center">
            <label for="date">Date</label>
          </div>
          <div class="col-4 col-10-small">
            <input id="date"
                   type="date"
                   class="<?php echo e($errors->has('date') ? ' is-invalid' : ''); ?>"
                   name="date"
                   value="<?php echo e(old('date')); ?>"
                   required
                   autocomplete="Date" autofocus>

            <?php if($errors->has('date')): ?>
                <span class="invalid-feedback" role="alert">
                    <strong><?php echo e($errors->first('date')); ?></strong>
                </span>
            <?php endif; ?>
          </div>

          
          <div class="col-2 alg-self-center">
            <label for="hour">Hour</label>
          </div>
          <div class="col-4 col-10-small">
            <input id="hour"
                   type="time"
                   class="<?php echo e($errors->has('hour') ? ' is-invalid' : ''); ?>"
                   name="hour"
                   value="<?php echo e(old('hour')); ?>"
                   required
                   autocomplete="Hour" autofocus>

            <?php if($errors->has('hour')): ?>
                <span class="invalid-feedback" role="alert">
                    <strong><?php echo e($errors->first('hour')); ?></strong>
                </span>
            <?php endif; ?>
          </div>

          <div class="col-12">
            <ul class="actions float-right">
              <li><a href="<?php echo e(route('public.dashboard')); ?>" class="button button small" title="Back">Back</a></li>
              <li><button type="submit" class="button primary button small" title="Submit">Create Event</button></li>
            </ul>
          </div>

        </div>  
      </div>
  </form>
</section>

<script>
  var today = new Date();
  var dd = String(today.getDate()).padStart(2, '0');
  var mm = String(today.getMonth() + 1).padStart(2, '0'); //January is 0!
  var yyyy = today.getFullYear();

  today = yyyy + '-' + mm + '-' + dd;

  document.getElementById("date").min = today;
</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.publicMaster', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\EventAssistant\resources\views/public/pages/event/create.blade.php ENDPATH**/ ?>