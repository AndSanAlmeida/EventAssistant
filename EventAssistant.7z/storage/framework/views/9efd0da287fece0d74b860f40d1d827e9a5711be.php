<?php $__env->startSection('title', 'Profile'); ?>

<?php $__env->startSection('content'); ?>

<section class="main">

    
    <?php echo $__env->make('public.partials._alerts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <div class="row gtr-200">
      <div class="col-12">
        <h2>Profile</h2>
      </div>
    </div>

    <div class="row gtr-200">
        <div class="col-3 col-12-small">
            <span class="image fit">
                <img src="<?php echo e($user->profileImage()); ?>" alt="Profile Image">
            </span>
        </div>
        <div class="col-9 col-12-small">
            <ul class="alt">
                <li><b>Name: </b><?php echo e($user->name); ?></li>
                <li><b>Email: </b><?php echo e($user->email); ?></li>
            </ul>
            <ul class="actions">
                <li><a class="button primary small" href="<?php echo e(route('public.user.edit')); ?>" title="Edit Profile">Edit Profile</a></li>
                <li><a class="button primary small" href="<?php echo e(route('public.password.edit')); ?>" title="Change Password">Change Password</a></li>
            </ul>       
        </div>
    </div>   
</section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.publicMaster', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\EventAssistant\resources\views/public/pages/user/show.blade.php ENDPATH**/ ?>