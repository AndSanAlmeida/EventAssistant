<?php $__env->startSection('title', 'Edit Password'); ?>

<?php $__env->startSection('content'); ?>

<section class="main">

    
    <?php echo $__env->make('public.partials._alerts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <div class="row gtr-200">
      <div class="col-12">
        <h2>Update Password</h2>
      </div>
    </div>

    <form method="POST" action="<?php echo e(route('public.password.update')); ?>">
        <?php echo csrf_field(); ?>        

        
        <div class="row gtr-uniform">
            <div class="col-2 col-12-small alg-self-center">
                <label for="oldPassword"><?php echo e(__('Old Password')); ?></label>
            </div>
            <div class="col-6 col-12-small">
                <input id="oldPassword" type="password" class="<?php $__errorArgs = ['oldPassword'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="oldPassword" required autocomplete="oldPassword" autofocus>

                <?php $__errorArgs = ['oldPassword'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="invalid-feedback" role="alert">
                        <strong><?php echo e($message); ?></strong>
                    </span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
        </div>

        <br>

        
        <div class="row gtr-uniform">
            <div class="col-2 col-12-small alg-self-center">
                <label for="password" ><?php echo e(__('New Password')); ?></label>
            </div>
            <div class="col-6 col-12-small">
                <input id="password" type="password" class="<?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="password" required autocomplete="new-password">

                <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="invalid-feedback" role="alert">
                        <strong><?php echo e($message); ?></strong>
                    </span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div> 
        </div>

        <br>

        
        <div class="row gtr-uniform">
            <div class="col-2 col-12-small alg-self-center">
                <label for="password-confirm"><?php echo e(__('Confirm Password')); ?></label>
            </div>
            
            <div class="col-6 col-12-small">
                <input id="password-confirm" type="password" class="form-control" name="password_confirmation" required autocomplete="new-password">
            </div>

            
            <div class="col-12">
                <ul class="actions">
                    <li><button type="submit" class="button primary small" title="Submit"><?php echo e(__('Change Password')); ?></button></li>
                    <li><a href="<?php echo e(route('public.user.show', Auth::user()->id)); ?>" class="button small" title="Back">Back</a></li>
                </ul>
            </div>
        </div>

    </form>
</section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.publicMaster', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\EventAssistant\resources\views/public/pages/user/editPassword.blade.php ENDPATH**/ ?>