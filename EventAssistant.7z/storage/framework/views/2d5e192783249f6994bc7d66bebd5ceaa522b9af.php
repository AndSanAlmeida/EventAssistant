<!-- Custom fonts for this template-->
<link href="<?php echo e(asset('vendor/fontawesome-free/css/all.min.css')); ?>" rel="stylesheet" type="text/css">

<!-- Custom styles for this template-->
<link href="<?php echo e(asset('css/public.css')); ?>" rel="stylesheet"><?php /**PATH C:\laragon\www\EventAssistant\resources\views/public/partials/_styles.blade.php ENDPATH**/ ?>