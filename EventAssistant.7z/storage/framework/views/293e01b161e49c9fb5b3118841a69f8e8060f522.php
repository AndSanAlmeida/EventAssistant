<!-- JavaScript -->
<script src="<?php echo e(asset('vendor/jquery/jquery.min.js')); ?>"></script>
<script src="<?php echo e(asset('vendor/jquery-scrolly/jquery.scrolly.min.js')); ?>"></script>
<script src="<?php echo e(asset('vendor/browser/browser.min.js')); ?>"></script>
<script src="<?php echo e(asset('vendor/breakpoints/breakpoints.min.js')); ?>"></script>

<!-- Custom scripts for all pages-->
<script src="<?php echo e(asset('js/demo/util.js')); ?>"></script>
<script src="<?php echo e(asset('js/public.js')); ?>"></script>
<?php /**PATH C:\laragon\www\EventAssistant\resources\views/public/partials/_scripts.blade.php ENDPATH**/ ?>