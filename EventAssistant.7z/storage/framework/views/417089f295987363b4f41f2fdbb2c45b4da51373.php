<!-- DATATABLES -->
<script src="<?php echo e(asset('vendor/datatables/jquery.dataTables.min.js')); ?>"></script>
<script src="<?php echo e(asset('vendor/datatables/dataTables.bootstrap4.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/demo/datatables-demo.js')); ?>"></script>

<!-- CHARTS -->
<?php /**PATH C:\laragon\www\EventAssistant\resources\views/admin/partials/_adminScripts.blade.php ENDPATH**/ ?>