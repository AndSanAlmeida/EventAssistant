<?php $__env->startSection('title', 'Manage Users'); ?>

<?php $__env->startSection('content'); ?>
	<!-- Page Heading -->
	<div class="d-sm-flex align-items-center justify-content-between mb-4">
		<h1 class="h3 mb-0 text-gray-800">Manage <?php echo e($user->name); ?> Permitions</h1>
	</div>

	<div class="row">
		<div class="col-md-4">
			<div class="card shadow mb-4">
				<div class="card-header py-3">
					<h6 class="m-0 font-weight-bold text-primary">Permitions Available</h6>
				</div>
				<div class="card-body">
					<form action="<?php echo e(route('admin.users.update', ['user' => $user->id])); ?>" method="POST">
						
						<?php echo csrf_field(); ?>
						<?php echo e(method_field('PUT')); ?>


						<?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<div class="form-check">
								<input type="checkbox" name="roles[]" value="<?php echo e($role->id); ?>" <?php echo e($user->hasAnyRole($role->name) ? 'checked': ''); ?>>
								<label><?php echo e(ucfirst($role->name)); ?></label>
							</div>							
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

						<button type="submit" class="btn btn-primary btn-icon-split float-right">
							<span class="icon text-white-50">
		                      	<i class="fas fa-arrow-right"></i>
		                    </span>
		                    <span class="text">Submit</span>
						</button>

					</form>						
				</div>
			</div>
		</div>
	</div>
	
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.adminMaster', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\EventAssistant\resources\views/admin/pages/users/edit.blade.php ENDPATH**/ ?>