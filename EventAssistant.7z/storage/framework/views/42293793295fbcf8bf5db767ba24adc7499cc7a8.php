<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
	<head>
		<meta charset="utf-8">
		<meta http-equiv="x-ua-compatible" content="ie=edge">
		<title><?php echo $__env->yieldContent('title', 'Home'); ?> | <?php echo e(config('app.name')); ?></title>
		<meta name="description" content="${2}">
		<meta name="viewport" content="width=device-width, initial-scale=1">

		<link rel="manifest" href="site.webmanifest">
		<link rel="apple-touch-icon" href="icon.png">

		
		<?php echo $__env->make('public.partials._styles', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

	</head> 
	<body>

		<div id="wrapper">
			
			<?php echo $__env->make('public.includes.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

			
			<?php echo $__env->yieldContent('mainContent'); ?>

			
		    <?php echo $__env->yieldContent('content'); ?>

	        
			<?php echo $__env->make('public.includes.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
	    </div>

	    
		<?php echo $__env->make('public.partials._scripts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

		<script>
			window.ga=function(){ga.q.push(arguments)};ga.q=[];ga.l=+new Date;
			ga('create','UA-XXXXX-Y','auto');ga('send','pageview')
		</script>
		<script src="https://www.google-analytics.com/analytics.js" async defer></script>
	</body>
</html><?php /**PATH C:\laragon\www\EventAssistant\resources\views/layouts/publicMaster.blade.php ENDPATH**/ ?>