<footer id="footer">
    <p class="copyright">© <?php echo e(config('app.name')); ?>. Al rights reserved.</p>
    <ul class="icons">
        <li><a href="#" class="icon brands fa-twitter"><span class="label">Twitter</span></a></li>
        <li><a href="#" class="icon brands fa-facebook"><span class="label">Facebook</span></a></li>
        <li><a href="#" class="icon brands fa-instagram"><span class="label">Instagram</span></a></li>
        <li><a href="#" class="icon brands fa-linkedin"><span class="label">LinkedIn</span></a></li>
        <li><a href="#" class="icon brands fa-github"><span class="label">GitHub</span></a></li>
    </ul>
</footer><?php /**PATH C:\laragon\www\EventAssistant\resources\views/public/includes/footer.blade.php ENDPATH**/ ?>