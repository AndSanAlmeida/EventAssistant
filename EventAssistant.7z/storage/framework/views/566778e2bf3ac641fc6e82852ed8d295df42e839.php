<?php $__env->startSection('title', 'Dashboard'); ?>

<?php $__env->startSection('content'); ?>

	<section class="main">

		<?php if(session('status')): ?>
			<div class="alert alert-success" role="alert">
				<?php echo e(session('status')); ?>

			</div>
		<?php endif; ?>

		<?php echo $__env->make('public.partials._alerts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

		<div class="row gtr-200">
		  <div class="col-12">
			<h2>Dashboard</h2>
		  </div>
		</div>

		<div class="row gtr-uniform">
			<div class="col-6">
				<h4>List of Events</h4>
			</div>
			<div class="col-6 align-right">
				<a href="<?php echo e(route('public.event.create')); ?>" class="button icon small"><i class="fas fa-plus"></i>Add New Event</a>
			</div>

			<?php if(auth()->user()->getUserEvents()->isEmpty()): ?>

				<span class="invalid-feedback" role="alert">
                    <strong>There is no events yiet! You must first create one.</strong>
                </span>

			<?php else: ?>

				<div class="col-12">
					<div class="table-wrapper">
					    <table>
					        <thead>
					            <tr>
					                <th>Name</th>
					                <th>Date</th>
					                <th>Status</th>
					                <th>Actions</th>
					            </tr>
					        </thead>
					        <tbody>
					        	<?php $__currentLoopData = auth()->user()->events; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $event): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					            	<tr>
					                	<td><?php echo e($event->name); ?></td>
					                	<td><?php echo e(date('d, F, Y', strtotime($event->date))); ?></td>
					                	<td><?php echo $event->isActive(); ?></td>
					                	<td>
					                		<ul class="actions no-margin">
					                			<li><a href="#" class="button xsmall" title="Details"><i class="far fa-eye"></i> Details</a></li>
					                			<li><a href="#" class="button xsmall" title="Update"><i class="far fa-edit"></i> Update</a></li>
					                			<li><a href="#" class="button primary xsmall" title="Delete"><i class="far fa-trash-alt"></i> Delete</a></li>
					                		</ul>
					                	</td>
					            	</tr>
					            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					        </tbody>
					    </table>
					</div>
				</div>	
				
			<?php endif; ?>

		</div>
	</section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.publicMaster', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\EventAssistant\resources\views/public/pages/dashboard.blade.php ENDPATH**/ ?>