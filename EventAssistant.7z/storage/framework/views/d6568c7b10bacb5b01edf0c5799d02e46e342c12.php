<?php $__env->startSection('title', 'Edit Profile'); ?>

<?php $__env->startSection('content'); ?>

<section class="main">

  
  <?php echo $__env->make('public.partials._alerts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  
  <div class="row gtr-200">
    <div class="col-12">
      <h2>Update Profile</h2>
    </div>
  </div>

  <form action="<?php echo e(route('public.user.update')); ?>" enctype="multipart/form-data" method="POST">
      <?php echo csrf_field(); ?>
      <?php echo method_field('PATCH'); ?>

      <div class="row gtr-200">

          <div class="col-3 col-12-small">
            <span class="image fit">
              <img src="<?php echo e($user->profileImage()); ?>" alt="Profile Image">
            </span>

            

          </div>

          <div class="col-9 col-12-small">  
            <div class="row gtr-uniform">

              
              <div class="col-2 alg-self-center">
                <label for="name">Name</label>
              </div>
              <div class="col-10">              
                <input id="name"
                       type="text"
                       class="<?php echo e($errors->has('name') ? ' is-invalid' : ''); ?>"
                       name="name"
                       value="<?php echo e(old('name') ?? $user->name); ?>"
                       autocomplete="Name" autofocus>

                  <?php if($errors->has('name')): ?>
                    <span class="invalid-feedback" role="alert">
                        <strong><?php echo e($errors->first('name')); ?></strong>
                    </span>
                  <?php endif; ?>
              </div>

              
              <div class="col-2 alg-self-center">
                <label for="email">Email</label>
              </div>
              <div class="col-10">
                <input id="email"
                       type="email"
                       class="<?php echo e($errors->has('email') ? ' is-invalid' : ''); ?>"
                       name="email"
                       value="<?php echo e(old('email') ?? $user->email); ?>"
                       autocomplete="Email" autofocus>

                <?php if($errors->has('email')): ?>
                    <span class="invalid-feedback" role="alert">
                        <strong><?php echo e($errors->first('email')); ?></strong>
                    </span>
                <?php endif; ?>
              </div>

              <div class="col-12 form-field-file">
              
              <label for="avatar"><i class="fas fa-upload"></i>Change Profile Image</label>
              <input type="file" id="avatar" name="avatar" class="button">

              <?php if($errors->has('avatar')): ?>
                  <strong><?php echo e($errors->first('avatar')); ?></strong>
              <?php endif; ?>
            </div>

              <div class="col-12">
                <ul class="actions">
                  <li><button class="button primary button small" title="Submit">Save Profile</button></li>
                  <li><a href="<?php echo e(route('public.user.show', $user->id)); ?>" class="button small" title="Back">Back</a></li>
                </ul>
              </div>

            </div>  
          </div>
      </div>
  </form>
</section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.publicMaster', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\EventAssistant\resources\views/public/pages/user/edit.blade.php ENDPATH**/ ?>