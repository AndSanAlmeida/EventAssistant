<?php $__env->startSection('title', 'Profile'); ?>

<?php $__env->startSection('content'); ?>
	Profile
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\EventAssistant\resources\views/public/pages/user/index.blade.php ENDPATH**/ ?>