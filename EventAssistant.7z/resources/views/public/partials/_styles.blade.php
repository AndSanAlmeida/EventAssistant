<!-- Custom fonts for this template-->
<link href="{{ asset('vendor/fontawesome-free/css/all.min.css') }}" rel="stylesheet" type="text/css">

<!-- Custom styles for this template-->
<link href="{{ asset('css/public.css') }}" rel="stylesheet">