<!-- JavaScript -->
<script src="{{ asset('vendor/jquery/jquery.min.js') }}"></script>
<script src="{{ asset('vendor/jquery-scrolly/jquery.scrolly.min.js') }}"></script>
<script src="{{ asset('vendor/browser/browser.min.js') }}"></script>
<script src="{{ asset('vendor/breakpoints/breakpoints.min.js') }}"></script>

<!-- Custom scripts for all pages-->
<script src="{{ asset('js/demo/util.js') }}"></script>
<script src="{{ asset('js/public.js') }}"></script>
